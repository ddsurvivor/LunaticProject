using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayingSystem : MonoBehaviour
{
    public static string 可用物品类型;
}
