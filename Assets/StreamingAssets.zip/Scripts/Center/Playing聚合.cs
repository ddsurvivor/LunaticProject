using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Playing聚合 : MonoBehaviour
{
   public 大地图System 大地图;
   public 剧本System 剧本;
   
}
